import os
from PIL import Image
import numpy as np
import pandas as pd

dirs = ["angry", "disgust", "fear", "happy", "sad", "surprise", "neutral"]

def getResized(pic):
    img = Image.open(pic)
    img = img.convert('L')
    img = img.resize((48,48))
    arr = np.array(img)
    return arr


images = []
emotions = []

#count = 1
for i in range(len(dirs)):
    #print(i, dirs[i])
    folder = dirs[i]
    files = os.listdir(dirs[i])
    for file in files:
        #print(count, end=', ')
        filePath = os.path.join(folder, file)
        array = getResized(filePath)
        images.append(array)
        emotions.append(i)
        #count += 1

new_data = pd.DataFrame()
new_data['image'] = images
new_data['emotion'] = emotions

new_data.to_pickle("./harish_expr.zip", compression='zip', protocol = 4)
